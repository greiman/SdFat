var searchData=
[
  ['datalength_0',['dataLength',['../class_ex_fat_file.html#abc1acc08645049680144c8c4bf2fe8ba',1,'ExFatFile']]],
  ['datastartsector_1',['dataStartSector',['../class_fat_partition.html#a7e89ec91780f7dfa060b261c605bf2e5',1,'FatPartition::dataStartSector()'],['../class_fs_volume.html#a79cebeb23cb3cdaa06550475fe24272a',1,'FsVolume::dataStartSector()']]],
  ['datetimecallback_2',['dateTimeCallback',['../class_sd_file.html#a2d78e6a8cedbf8ce545af68457b43bf1',1,'SdFile']]],
  ['datetimecallbackcancel_3',['dateTimeCallbackCancel',['../class_sd_file.html#ad266770d0a779d1a528a3997aee5142d',1,'SdFile']]],
  ['dbgfat_4',['dbgFat',['../class_fat_partition.html#a0af1e91a311180119b4a2c85d7e6e87e',1,'FatPartition']]],
  ['deactivate_5',['deactivate',['../class_sd_spi_arduino_driver.html#ae88a255f533e3acb41d1221025a69b55',1,'SdSpiArduinoDriver::deactivate()'],['../class_sd_spi_base_class.html#ae3a5ede781e390263382fcf7765d665d',1,'SdSpiBaseClass::deactivate()'],['../class_sd_spi_soft_driver.html#a05315e4128ae7263d9e68119d6ae4308',1,'SdSpiSoftDriver::deactivate()']]],
  ['dec_6',['dec',['../classios__base.html#a2826aed005e7c1f6858060cddae7971a',1,'ios_base::dec()'],['../ios_8h.html#acefd615ed6ae0a0ca25153eafda6e086',1,'dec(ios_base &amp;str):&#160;ios.h']]],
  ['dedicatedspicard_7',['DedicatedSpiCard',['../class_dedicated_spi_card.html',1,'DedicatedSpiCard'],['../class_dedicated_spi_card.html#adb96edd4160ba68736c344078c10bf81',1,'DedicatedSpiCard::DedicatedSpiCard()']]],
  ['destructor_5fcloses_5ffile_8',['DESTRUCTOR_CLOSES_FILE',['../_sd_fat_config_8h.html#a9a2b1ca4d91cff876f48deeaacbc33da',1,'SdFatConfig.h']]],
  ['direntriespercluster_9',['dirEntriesPerCluster',['../class_fat_partition.html#a00ea37a7dadc4578236e14e84dc7839e',1,'FatPartition']]],
  ['direntry_10',['dirEntry',['../class_fat_file.html#a2f4e9ab3056125b07f15d14ca26d5346',1,'FatFile']]],
  ['dirindex_11',['dirIndex',['../class_ex_fat_file.html#aea5b18625a06892a03a8d17c66b71717',1,'ExFatFile::dirIndex()'],['../class_fat_file.html#a7f0d6488685dc3be61720caca49fa116',1,'FatFile::dirIndex()'],['../class_fs_base_file.html#a41626a85a4665db2400ee6e251c66afd',1,'FsBaseFile::dirIndex()']]],
  ['dirpos_5ft_12',['DirPos_t',['../struct_dir_pos__t.html',1,'']]],
  ['dirsize_13',['dirSize',['../class_fat_file.html#ae2ed15f05c9ccbce355e7a8d3ce8382d',1,'FatFile']]],
  ['dirty_14',['dirty',['../class_fs_cache.html#af50f564561a2db190280769d4641147b',1,'FsCache']]],
  ['dmpfile_15',['dmpFile',['../class_fat_file.html#a4f01d27954ae49aeb6888ac7302f55d9',1,'FatFile']]]
];
