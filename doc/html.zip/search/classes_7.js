var searchData=
[
  ['minimumserial_0',['MinimumSerial',['../class_minimum_serial.html',1,'']]]
];
