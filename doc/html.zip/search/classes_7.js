var searchData=
[
  ['minimumserial_571',['MinimumSerial',['../class_minimum_serial.html',1,'']]]
];
