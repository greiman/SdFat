var searchData=
[
  ['minimumserial_536',['MinimumSerial',['../class_minimum_serial.html',1,'']]]
];
