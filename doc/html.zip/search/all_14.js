var searchData=
[
  ['validlength_0',['validLength',['../class_ex_fat_file.html#a9b299ba77e9287c74ce08b217a1bff44',1,'ExFatFile']]],
  ['vol_1',['vol',['../class_sd_base.html#ac527c2821cb72c5373c743c8440b83b6',1,'SdBase']]],
  ['volumebegin_2',['volumeBegin',['../class_sd_base.html#a1f1de2aac5384475b67506f86199e4c8',1,'SdBase']]],
  ['volumesectorcount_3',['volumeSectorCount',['../class_fat_partition.html#a916ba7d67711bb62daf12ecd47ca4b8e',1,'FatPartition']]]
];
