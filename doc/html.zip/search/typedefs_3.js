var searchData=
[
  ['pos_5ft_0',['pos_t',['../ios_8h.html#aae8adaedc486a4b2f67576fdeaf0a585',1,'ios.h']]],
  ['pos_5ftype_1',['pos_type',['../classios__base.html#a1f8c459d4597a781cc134e6626e00aee',1,'ios_base']]],
  ['print_5ft_2',['print_t',['../_sys_call_8h.html#ab4f210a7e2149c6c531486f1713c647b',1,'SysCall.h']]]
];
