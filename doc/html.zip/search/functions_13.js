var searchData=
[
  ['validlength_952',['validLength',['../class_ex_fat_file.html#a9b299ba77e9287c74ce08b217a1bff44',1,'ExFatFile']]],
  ['vol_953',['vol',['../class_sd_base.html#a20ed1868a6498cd336364c22d1df28a5',1,'SdBase']]],
  ['volumebegin_954',['volumeBegin',['../class_sd_base.html#a1f1de2aac5384475b67506f86199e4c8',1,'SdBase']]],
  ['volumesectorcount_955',['volumeSectorCount',['../class_fat_partition.html#a916ba7d67711bb62daf12ecd47ca4b8e',1,'FatPartition']]]
];
