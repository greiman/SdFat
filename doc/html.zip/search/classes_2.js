var searchData=
[
  ['cid_5ft_0',['cid_t',['../structcid__t.html',1,'']]],
  ['csd_5ft_1',['csd_t',['../structcsd__t.html',1,'']]]
];
