var searchData=
[
  ['r1_5fidle_5fstate_0',['R1_IDLE_STATE',['../_sd_card_info_8h.html#af72deea43f5b98d874e5d07c432d6167',1,'SdCardInfo.h']]],
  ['r1_5fillegal_5fcommand_1',['R1_ILLEGAL_COMMAND',['../_sd_card_info_8h.html#ad4feca4c2fd7987422d141128e80a06e',1,'SdCardInfo.h']]],
  ['r1_5fready_5fstate_2',['R1_READY_STATE',['../_sd_card_info_8h.html#abadef837d9bd6b89feb9bfef16c7782a',1,'SdCardInfo.h']]],
  ['read_5fstate_3',['READ_STATE',['../class_sd_spi_card.html#a6396387856a96d84bfcf70d3be98d891',1,'SdSpiCard']]],
  ['reserved1_4',['reserved1',['../structsds__t.html#afee02dd3e3289caa5f27077d3e49543f',1,'sds_t']]],
  ['reservedmanufacturer_5',['reservedManufacturer',['../structsds__t.html#a281da7d7d4bf291b681322f898af682f',1,'sds_t']]],
  ['right_6',['right',['../classios__base.html#aec064a12730b5d87e718c1864e29ac64',1,'ios_base']]]
];
