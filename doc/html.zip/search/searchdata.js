var indexSectionsWithContent =
{
  0: "_abcdefghiklmnoprstuvw~",
  1: "abcdefhimnoprst",
  2: "f",
  3: "abdefimoprst",
  4: "abcdefghiklmnoprstuvw~",
  5: "_abcdefghilmnoprstuvw",
  6: "fiops",
  7: "s",
  8: "bce",
  9: "ef",
  10: "cdefhimnsu",
  11: "als"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enums",
  8: "enumvalues",
  9: "related",
  10: "defines",
  11: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Enumerations",
  8: "Enumerator",
  9: "Friends",
  10: "Macros",
  11: "Pages"
};

