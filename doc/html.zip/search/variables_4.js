var searchData=
[
  ['dec_0',['dec',['../classios__base.html#a2826aed005e7c1f6858060cddae7971a',1,'ios_base']]]
];
