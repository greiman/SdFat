var searchData=
[
  ['khzsdclk_0',['kHzSdClk',['../class_teensy_sdio_card.html#a781a7d6a186a7b57e968e21d654aba7f',1,'TeensySdioCard::kHzSdClk()'],['../class_pio_sdio_card.html#a3caf886ad3202efbf07aaaeb2605395c',1,'PioSdioCard::kHzSdClk()']]]
];
