var searchData=
[
  ['_5f_5fbrkval_892',['__brkval',['../_free_stack_8h.html#ad193a2cc121e0d4614a1c21eb463fb56',1,'FreeStack.h']]],
  ['_5f_5fbss_5fend_893',['__bss_end',['../_free_stack_8h.html#adbad17f740c2d7f2bc4833681c93c932',1,'FreeStack.h']]]
];
